package AnimalFarm.model;

import java.util.Date;

public class FarmAnimal {
    private int id;
    private String breed;
    private Date bornOn;

    // Constructor con 3 parámetros (coincide con super(id, breed, bornOn))
    public FarmAnimal(int id, String breed, Date bornOn) {
        this.id = id;
        this.breed = breed;
        this.bornOn = bornOn;
    }

    public int getAgeInMonths() {
        return 0;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public Date getBornOn() {
        return bornOn;
    }

    public void setBornOn(Date bornOn) {
        this.bornOn = bornOn;
    }

    @Override
    public String toString() {
        return "id=" + id + ", breed=" + breed + ", bornOn=" + bornOn;
    }
}