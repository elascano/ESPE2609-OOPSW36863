package AnimalFarm.model;

import java.util.Date;

/**
 *
 * @author Lino
 */
public class Chicken extends FarmAnimal {
    private boolean isMolting;
    private int numbersOfEggsInMonth;
    private boolean isMeet;

    public void layAnEgg() {
        System.out.println("The chicken is laying an egg");
    }

    public Chicken(boolean isMolting, int numbersOfEggsInMonth, boolean isMeet, int id, String breed, Date bornOn) {
        super(id, breed, bornOn);
        this.isMolting = isMolting;
        this.numbersOfEggsInMonth = numbersOfEggsInMonth;
        this.isMeet = isMeet;
    }

    @Override
    public String toString() {
        return "Chicken{" + super.toString() + ", isMolting=" + isMolting + ", numbersOfEggsInMonth=" + numbersOfEggsInMonth + ", isMeet=" + isMeet + '}';
    }

    /**
     * @return the isMolting
     */
    public boolean isIsMolting() {
        return isMolting;
    }

    /**
     * @param isMolting the isMolting to set
     */
    public void setIsMolting(boolean isMolting) {
        this.isMolting = isMolting;
    }

    /**
     * @return the numbersOfEggsInMonth
     */
    public int getNumbersOfEggsInMonth() {
        return numbersOfEggsInMonth;
    }

    /**
     * @param numbersOfEggsInMonth the numbersOfEggsInMonth to set
     */
    public void setNumbersOfEggsInMonth(int numbersOfEggsInMonth) {
        this.numbersOfEggsInMonth = numbersOfEggsInMonth;
    }

    /**
     * @return the isMeet
     */
    public boolean isIsMeet() {
        return isMeet;
    }

    /**
     * @param isMeet the isMeet to set
     */
    public void setIsMeet(boolean isMeet) {
        this.isMeet = isMeet;
    }
}