package AnimalFarm.model;

import java.util.Date;

/**
 *
 * @author Lino
 */
public class Cow extends FarmAnimal {
    private boolean isProducingMilk;
    private float litersOfMilk;

    public void milk() {
        System.out.println("Milking the cow ");
    }

    public Cow(boolean isProducingMilk, float litersOfMilk, int id, String breed, Date bornOn) {
        super(id, breed, bornOn);
        this.isProducingMilk = isProducingMilk;
        this.litersOfMilk = litersOfMilk;
    }

    @Override
    public String toString() {
        return "Cow{" + super.toString() + ", isProducingMilk=" + isProducingMilk + ", litersOfMilk=" + litersOfMilk + '}';
    }

    public boolean isIsProducingMilk() {
        return isProducingMilk;
    }

    public void setIsProducingMilk(boolean isProducingMilk) {
        this.isProducingMilk = isProducingMilk;
    }

    public float getLitersOfMilk() {
        return litersOfMilk;
    }

    public void setLitersOfMilk(float litersOfMilk) {
        this.litersOfMilk = litersOfMilk;
    }
}