package AnimalFarm.controller;

import AnimalFarm.model.FarmAnimal;
import java.util.ArrayList;

/**
 *
 * @author Lino
 */
public class FarmController {
    private ArrayList<FarmAnimal> animals;

    public FarmController() {
        this.animals = new ArrayList<>();
    }

    public void addAnimal(FarmAnimal animal) {
        animals.add(animal);
        System.out.println("-> Animal successfully registered in the farm!");
    }

    public void showAnimals() {
        System.out.println("\n========= LIST OF ANIMALS IN THE FARM =========");
        if (animals.isEmpty()) {
            System.out.println("There are no animals registered in the farm yet.");
        } else {
            for (FarmAnimal animal : animals) {
                System.out.println(animal);
            }
        }
        System.out.println("===============================================");
    }
}