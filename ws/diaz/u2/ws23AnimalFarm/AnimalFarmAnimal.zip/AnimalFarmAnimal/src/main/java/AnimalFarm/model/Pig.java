package AnimalFarm.model;

import java.util.Date;

/**
 *
 * @author Lino
 */
public class Pig extends FarmAnimal {

    public void oink() {
        System.out.println("The pig is oinking");
    }

    public Pig(int id, String breed, Date bornOn) {
        super(id, breed, bornOn);
    }

    @Override
    public String toString() {
        return "Pig{" + super.toString() + '}';
    }
}