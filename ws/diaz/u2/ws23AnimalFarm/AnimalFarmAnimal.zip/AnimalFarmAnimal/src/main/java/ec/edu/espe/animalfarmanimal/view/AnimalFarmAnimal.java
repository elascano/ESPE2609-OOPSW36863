package ec.edu.espe.animalfarmanimal.view;

import AnimalFarm.controller.FarmController;
import AnimalFarm.model.Chicken;
import AnimalFarm.model.Cow;
import AnimalFarm.model.Pig;
import AnimalFarm.model.Sheep;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Lino
 */
public class AnimalFarmAnimal {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FarmController controller = new FarmController();
        int option = 0;

        System.out.println("Hello Lino Diaz Animal Farm");

        while (option != 6) {
            System.out.println("\n--- ANIMAL FARM MENU ---");
            System.out.println("1. Register Chicken");
            System.out.println("2. Register Cow");
            System.out.println("3. Register Pig");
            System.out.println("4. Register Sheep");
            System.out.println("5. Show all animals");
            System.out.println("6. Exit");
            System.out.print("Select an option: ");
            option = scanner.nextInt();
            scanner.nextLine(); // Clear keyboard buffer

            switch (option) {
                case 1:
                    System.out.println("\n-- New Chicken --");
                    System.out.print("ID: ");
                    int cId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Breed: ");
                    String cBreed = scanner.nextLine();
                    System.out.print("Is molting? (true/false): ");
                    boolean isMolting = scanner.nextBoolean();
                    System.out.print("Number of eggs per month: ");
                    int eggs = scanner.nextInt();
                    System.out.print("Is meat chicken? (true/false): ");
                    boolean isMeet = scanner.nextBoolean();

                    Chicken chicken = new Chicken(isMolting, eggs, isMeet, cId, cBreed, new Date());
                    controller.addAnimal(chicken);
                    break;

                case 2:
                    System.out.println("\n-- New Cow --");
                    System.out.print("ID: ");
                    int cowId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Breed: ");
                    String cowBreed = scanner.nextLine();
                    System.out.print("Is producing milk? (true/false): ");
                    boolean isProducingMilk = scanner.nextBoolean();
                    System.out.print("Liters of milk (e.g., 12.5): ");
                    float liters = scanner.nextFloat();

                    Cow cow = new Cow(isProducingMilk, liters, cowId, cowBreed, new Date());
                    controller.addAnimal(cow);
                    break;

                case 3:
                    System.out.println("\n-- New Pig --");
                    System.out.print("ID: ");
                    int pId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Breed: ");
                    String pBreed = scanner.nextLine();

                    Pig pig = new Pig(pId, pBreed, new Date());
                    controller.addAnimal(pig);
                    break;

                case 4:
                    System.out.println("\n-- New Sheep --");
                    System.out.print("ID: ");
                    int sId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Breed: ");
                    String sBreed = scanner.nextLine();

                    Sheep sheep = new Sheep(new Date(), sId, sBreed, new Date());
                    controller.addAnimal(sheep);
                    break;

                case 5:
                    controller.showAnimals();
                    break;

                case 6:
                    System.out.println("Exiting Animal Farm system...");
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
        scanner.close();
    }
}