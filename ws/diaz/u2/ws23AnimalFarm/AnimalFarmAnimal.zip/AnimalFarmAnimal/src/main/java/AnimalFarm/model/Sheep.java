package AnimalFarm.model;

import java.util.Date;

/**
 *
 * @author Lino
 */
public class Sheep extends FarmAnimal {
    private Date lastSheering;

    public void sheer() {
        System.out.println("Sheering the sheep");
    }

    public Sheep(Date lastSheering, int id, String breed, Date bornOn) {
        super(id, breed, bornOn);
        this.lastSheering = lastSheering;
    }

    @Override
    public String toString() {
        return "Sheep{" + super.toString() + ", lastSheering=" + lastSheering + '}';
    }

    public Date getLastSheering() {
        return lastSheering;
    }

    public void setLastSheering(Date lastSheering) {
        this.lastSheering = lastSheering;
    }
}