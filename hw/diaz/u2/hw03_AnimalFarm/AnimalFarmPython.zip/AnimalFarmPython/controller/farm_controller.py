from model.farm_animal import FarmAnimal

class FarmController:
    def __init__(self):
        self._animals: list[FarmAnimal] = []

    def add_animal(self, animal: FarmAnimal):
        self._animals.append(animal)
        print("-> Animal successfully registered in the farm!")

    def show_animals(self):
        print("\n========= LIST OF ANIMALS IN THE FARM =========")
        if not self._animals:
            print("There are no animals registered in the farm yet.")
        else:
            for animal in self._animals:
                print(animal)
        print("===============================================")