import sys
import os
from datetime import date

# Permite importar model y controller desde la carpeta raíz
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from controller.farm_controller import FarmController
from model.chicken import Chicken
from model.cow import Cow
from model.pig import Pig
from model.sheep import Sheep

def read_bool(prompt: str) -> bool:
    return input(prompt).strip().lower() == "true"

def main():
    controller = FarmController()
    option = 0

    print("Hello Lino Diaz Animal Farm")

    while option != 6:
        print("\n--- ANIMAL FARM MENU ---")
        print("1. Register Chicken")
        print("2. Register Cow")
        print("3. Register Pig")
        print("4. Register Sheep")
        print("5. Show all animals")
        print("6. Exit")

        try:
            option = int(input("Select an option: "))
        except ValueError:
            print("Invalid input. Please enter a number.")
            continue

        if option == 1:
            print("\n-- New Chicken --")
            c_id = int(input("ID: "))
            c_breed = input("Breed: ")
            is_molting = read_bool("Is molting? (true/false): ")
            eggs = int(input("Number of eggs per month: "))
            is_meet = read_bool("Is meat chicken? (true/false): ")

            chicken = Chicken(is_molting, eggs, is_meet, c_id, c_breed, date.today())
            controller.add_animal(chicken)

        elif option == 2:
            print("\n-- New Cow --")
            cow_id = int(input("ID: "))
            cow_breed = input("Breed: ")
            is_producing_milk = read_bool("Is producing milk? (true/false): ")
            liters = float(input("Liters of milk (e.g., 12.5): "))

            cow = Cow(is_producing_milk, liters, cow_id, cow_breed, date.today())
            controller.add_animal(cow)

        elif option == 3:
            print("\n-- New Pig --")
            p_id = int(input("ID: "))
            p_breed = input("Breed: ")

            pig = Pig(p_id, p_breed, date.today())
            controller.add_animal(pig)

        elif option == 4:
            print("\n-- New Sheep --")
            s_id = int(input("ID: "))
            s_breed = input("Breed: ")

            sheep = Sheep(date.today(), s_id, s_breed, date.today())
            controller.add_animal(sheep)

        elif option == 5:
            controller.show_animals()

        elif option == 6:
            print("Exiting Animal Farm system...")

        else:
            print("Invalid option. Please try again.")

if __name__ == "__main__":
    main()