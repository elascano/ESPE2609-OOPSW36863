from datetime import date

class FarmAnimal:
    def __init__(self, animal_id: int, breed: str, born_on: date):
        self._id = animal_id
        self._breed = breed
        self._born_on = born_on

    def get_age_in_months(self) -> int:
        today = date.today()
        return (today.year - self._born_on.year) * 12 + (today.month - self._born_on.month)

    # Getters y Setters
    def get_id(self) -> int:
        return self._id

    def set_id(self, animal_id: int):
        self._id = animal_id

    def get_breed(self) -> str:
        return self._breed

    def set_breed(self, breed: str):
        self._breed = breed

    def get_born_on(self) -> date:
        return self._born_on

    def set_born_on(self, born_on: date):
        self._born_on = born_on

    def __str__(self) -> str:
        return f"id={self._id}, breed={self._breed}, bornOn={self._born_on}"