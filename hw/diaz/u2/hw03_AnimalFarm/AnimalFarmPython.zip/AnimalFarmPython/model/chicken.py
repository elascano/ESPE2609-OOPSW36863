from datetime import date
from model.farm_animal import FarmAnimal

class Chicken(FarmAnimal):
    def __init__(self, is_molting: bool, numbers_of_eggs_in_month: int, is_meet: bool, animal_id: int, breed: str, born_on: date):
        super().__init__(animal_id, breed, born_on)
        self._is_molting = is_molting
        self._numbers_of_eggs_in_month = numbers_of_eggs_in_month
        self._is_meet = is_meet

    def lay_an_egg(self):
        print("The chicken is laying an egg")

    def __str__(self) -> str:
        return f"Chicken{{{super().__str__()}, isMolting={self._is_molting}, numbersOfEggsInMonth={self._numbers_of_eggs_in_month}, isMeet={self._is_meet}}}"