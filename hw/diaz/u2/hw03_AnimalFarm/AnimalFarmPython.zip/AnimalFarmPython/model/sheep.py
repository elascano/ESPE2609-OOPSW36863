from datetime import date
from model.farm_animal import FarmAnimal

class Sheep(FarmAnimal):
    def __init__(self, last_sheering: date, animal_id: int, breed: str, born_on: date):
        super().__init__(animal_id, breed, born_on)
        self._last_sheering = last_sheering

    def sheer(self):
        print("Sheering the sheep")

    def __str__(self) -> str:
        return f"Sheep{{{super().__str__()}, lastSheering={self._last_sheering}}}"