from datetime import date
from model.farm_animal import FarmAnimal

class Cow(FarmAnimal):
    def __init__(self, is_producing_milk: bool, liters_of_milk: float, animal_id: int, breed: str, born_on: date):
        super().__init__(animal_id, breed, born_on)
        self._is_producing_milk = is_producing_milk
        self._liters_of_milk = liters_of_milk

    def milk(self):
        print("Milking the cow")

    def __str__(self) -> str:
        return f"Cow{{{super().__str__()}, isProducingMilk={self._is_producing_milk}, litersOfMilk={self._liters_of_milk}}}"