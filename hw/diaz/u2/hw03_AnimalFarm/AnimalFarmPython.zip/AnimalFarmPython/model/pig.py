from datetime import date
from model.farm_animal import FarmAnimal

class Pig(FarmAnimal):
    def __init__(self, animal_id: int, breed: str, born_on: date):
        super().__init__(animal_id, breed, born_on)

    def oink(self):
        print("The pig is oinking")

    def __str__(self) -> str:
        return f"Pig{{{super().__str__()}}}"