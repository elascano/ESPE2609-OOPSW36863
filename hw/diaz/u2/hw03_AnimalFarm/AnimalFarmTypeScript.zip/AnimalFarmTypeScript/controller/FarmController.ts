import { FarmAnimal } from "../model/FarmAnimal";

export class FarmController {
    private animals: FarmAnimal[] = [];

    public addAnimal(animal: FarmAnimal): void {
        this.animals.push(animal);
        console.log("-> Animal successfully registered in the farm!");
    }

    public showAnimals(): void {
        console.log("\n========= LIST OF ANIMALS IN THE FARM =========");
        if (this.animals.length === 0) {
            console.log("There are no animals registered in the farm yet.");
        } else {
            for (const animal of this.animals) {
                console.log(animal.toString());
            }
        }
        console.log("===============================================");
    }
}