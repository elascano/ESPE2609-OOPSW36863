import { FarmAnimal } from "./FarmAnimal";

export class Pig extends FarmAnimal {
    constructor(id: number, breed: string, bornOn: Date) {
        super(id, breed, bornOn);
    }

    public oink(): void {
        console.log("The pig is oinking");
    }

    public override toString(): string {
        return `Pig{${super.toString()}}`;
    }
}