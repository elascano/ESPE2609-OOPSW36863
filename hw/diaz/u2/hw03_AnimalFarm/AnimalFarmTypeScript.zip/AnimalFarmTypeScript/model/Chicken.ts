import { FarmAnimal } from "./FarmAnimal";

export class Chicken extends FarmAnimal {
    private isMolting: boolean;
    private numbersOfEggsInMonth: number;
    private isMeet: boolean;

    constructor(isMolting: boolean, numbersOfEggsInMonth: number, isMeet: boolean, id: number, breed: string, bornOn: Date) {
        super(id, breed, bornOn);
        this.isMolting = isMolting;
        this.numbersOfEggsInMonth = numbersOfEggsInMonth;
        this.isMeet = isMeet;
    }

    public layAnEgg(): void {
        console.log("The chicken is laying an egg");
    }

    public override toString(): string {
        return `Chicken{${super.toString()}, isMolting=${this.isMolting}, numbersOfEggsInMonth=${this.numbersOfEggsInMonth}, isMeet=${this.isMeet}}`;
    }
}