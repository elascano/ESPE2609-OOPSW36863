import { FarmAnimal } from "./FarmAnimal";

export class Sheep extends FarmAnimal {
    private lastSheering: Date;

    constructor(lastSheering: Date, id: number, breed: string, bornOn: Date) {
        super(id, breed, bornOn);
        this.lastSheering = lastSheering;
    }

    public sheer(): void {
        console.log("Sheering the sheep");
    }

    public override toString(): string {
        return `Sheep{${super.toString()}, lastSheering=${this.lastSheering.toDateString()}}`;
    }
}