import { FarmAnimal } from "./FarmAnimal";

export class Cow extends FarmAnimal {
    private isProducingMilk: boolean;
    private litersOfMilk: number;

    constructor(isProducingMilk: boolean, litersOfMilk: number, id: number, breed: string, bornOn: Date) {
        super(id, breed, bornOn);
        this.isProducingMilk = isProducingMilk;
        this.litersOfMilk = litersOfMilk;
    }

    public milk(): void {
        console.log("Milking the cow");
    }

    public override toString(): string {
        return `Cow{${super.toString()}, isProducingMilk=${this.isProducingMilk}, litersOfMilk=${this.litersOfMilk}}`;
    }
}