export class FarmAnimal {
    private id: number;
    private breed: string;
    private bornOn: Date;

    constructor(id: number, breed: string, bornOn: Date) {
        this.id = id;
        this.breed = breed;
        this.bornOn = bornOn;
    }

    public getAgeInMonths(): number {
        const today = new Date();
        return (today.getFullYear() - this.bornOn.getFullYear()) * 12 + (today.getMonth() - this.bornOn.getMonth());
    }

    public getId(): number { return this.id; }
    public setId(id: number): void { this.id = id; }

    public getBreed(): string { return this.breed; }
    public setBreed(breed: string): void { this.breed = breed; }

    public getBornOn(): Date { return this.bornOn; }
    public setBornOn(bornOn: Date): void { this.bornOn = bornOn; }

    public toString(): string {
        return `id=${this.id}, breed=${this.breed}, bornOn=${this.bornOn.toDateString()}`;
    }
}