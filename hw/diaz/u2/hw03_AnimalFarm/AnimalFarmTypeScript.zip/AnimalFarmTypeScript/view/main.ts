import * as readline from "readline/promises";
import { stdin as input, stdout as output } from "process";
import { FarmController } from "../controller/FarmController";
import { Chicken } from "../model/Chicken";
import { Cow } from "../model/Cow";
import { Pig } from "../model/Pig";
import { Sheep } from "../model/Sheep";

async function main() {
    const rl = readline.createInterface({ input, output });
    const controller = new FarmController();
    let option = 0;

    console.log("Hello Lino Diaz Animal Farm");

    while (option !== 6) {
        console.log("\n--- ANIMAL FARM MENU ---");
        console.log("1. Register Chicken");
        console.log("2. Register Cow");
        console.log("3. Register Pig");
        console.log("4. Register Sheep");
        console.log("5. Show all animals");
        console.log("6. Exit");

        const answer = await rl.question("Select an option: ");
        option = parseInt(answer);

        switch (option) {
            case 1: {
                console.log("\n-- New Chicken --");
                const cId = parseInt(await rl.question("ID: "));
                const cBreed = await rl.question("Breed: ");
                const isMolting = (await rl.question("Is molting? (true/false): ")).trim().toLowerCase() === "true";
                const eggs = parseInt(await rl.question("Number of eggs per month: "));
                const isMeet = (await rl.question("Is meat chicken? (true/false): ")).trim().toLowerCase() === "true";

                const chicken = new Chicken(isMolting, eggs, isMeet, cId, cBreed, new Date());
                controller.addAnimal(chicken);
                break;
            }
            case 2: {
                console.log("\n-- New Cow --");
                const cowId = parseInt(await rl.question("ID: "));
                const cowBreed = await rl.question("Breed: ");
                const isProducingMilk = (await rl.question("Is producing milk? (true/false): ")).trim().toLowerCase() === "true";
                const liters = parseFloat(await rl.question("Liters of milk (e.g., 12.5): "));

                const cow = new Cow(isProducingMilk, liters, cowId, cowBreed, new Date());
                controller.addAnimal(cow);
                break;
            }
            case 3: {
                console.log("\n-- New Pig --");
                const pId = parseInt(await rl.question("ID: "));
                const pBreed = await rl.question("Breed: ");

                const pig = new Pig(pId, pBreed, new Date());
                controller.addAnimal(pig);
                break;
            }
            case 4: {
                console.log("\n-- New Sheep --");
                const sId = parseInt(await rl.question("ID: "));
                const sBreed = await rl.question("Breed: ");

                const sheep = new Sheep(new Date(), sId, sBreed, new Date());
                controller.addAnimal(sheep);
                break;
            }
            case 5:
                controller.showAnimals();
                break;
            case 6:
                console.log("Exiting Animal Farm system...");
                break;
            default:
                console.log("Invalid option. Please try again.");
        }
    }

    rl.close();
}

main();