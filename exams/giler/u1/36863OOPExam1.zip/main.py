import sys
from controllers.truck_controller import TruckController


class MainMenu:
    def __init__(self):
        self._controller = TruckController()

    def start(self) -> None:
        while True:
            self._display_menu()
            choice = input("Select an option (1-3): ").strip()

            if choice == "1":
                self._create_truck_flow()
            elif choice == "2":
                self._read_trucks_flow()
            elif choice == "3":
                print("\nExiting application. Goodbye!")
                sys.exit(0)
            else:
                print("\n[Error] Invalid choice. Please enter 1, 2, or 3.\n")

    def _display_menu(self) -> None:
        print("=" * 40)
        print("       TRUCK MANAGEMENT SYSTEM")
        print("=" * 40)
        print("1. Create and Save New Truck")
        print("2. Read All Trucks from JSON")
        print("3. Exit")
        print("-" * 40)

    def _create_truck_flow(self) -> None:
        print("\n--- CREATE NEW TRUCK ---")
        truck_id = self._read_non_empty_string("Enter Truck ID: ")

        if self._controller.truck_exists(truck_id):
            print(f"\n[Error] A truck with ID '{truck_id}' already exists. Operation aborted.\n")
            return

        brand = self._read_non_empty_string("Enter Brand: ")
        payload = self._read_positive_float("Enter Payload Capacity (kg): ")
        year = self._read_valid_year("Enter Manufacturing Year: ")

        try:
            truck = self._controller.add_truck(truck_id, brand, payload, year)
            print(f"\n[Success] Truck created and saved to JSON: {truck}\n")
        except ValueError as err:
            print(f"\n[Error] {err}\n")

    def _read_trucks_flow(self) -> None:
        print("\n--- READING TRUCKS FROM JSON ---")
        trucks = self._controller.get_all_trucks()

        if not trucks:
            print("No records found in JSON file.\n")
            return

        print(f"Total Records Found: {len(trucks)}")
        print("-" * 50)
        for index, truck in enumerate(trucks, start=1):
            print(f"{index}. {truck}")
        print("-" * 50 + "\n")

    @staticmethod
    def _read_non_empty_string(prompt: str) -> str:
        while True:
            value = input(prompt).strip()
            if value:
                return value
            print("[Invalid] Input cannot be empty. Try again.")

    @staticmethod
    def _read_positive_float(prompt: str) -> float:
        while True:
            try:
                value = float(input(prompt))
                if value > 0:
                    return value
                print("[Invalid] Value must be greater than zero.")
            except ValueError:
                print("[Invalid] Please enter a valid decimal number.")

    @staticmethod
    def _read_valid_year(prompt: str) -> int:
        while True:
            try:
                value = int(input(prompt))
                if 1900 <= value <= 2030:
                    return value
                print("[Invalid] Year must be between 1900 and 2030.")
            except ValueError:
                print("[Invalid] Please enter a valid integer year.")


if __name__ == "__main__":
    app = MainMenu()
    app.start()