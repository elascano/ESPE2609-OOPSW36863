from typing import List
from models.truck import Truck
from utils.json_manager import TruckJsonManager


class TruckController:
    def __init__(self, json_manager: TruckJsonManager = None):
        self._json_manager = json_manager or TruckJsonManager()
        self._trucks: List[Truck] = self._json_manager.read_trucks()

    def add_truck(self, truck_id: str, brand: str, payload_capacity_kg: float, year: int) -> Truck:
        """Creates a new Truck, appends it to the list, and persists to JSON file."""
        if self.truck_exists(truck_id):
            raise ValueError(f"Truck with ID '{truck_id}' already exists.")

        new_truck = Truck(truck_id, brand, payload_capacity_kg, year)
        self._trucks.append(new_truck)
        self._json_manager.save_trucks(self._trucks)
        return new_truck

    def get_all_trucks(self) -> List[Truck]:
        """Returns the current list of trucks."""
        return self._trucks

    def truck_exists(self, truck_id: str) -> bool:
        """Checks if a truck with the given ID already exists."""
        return any(truck.id.strip().lower() == truck_id.strip().lower() for truck in self._trucks)