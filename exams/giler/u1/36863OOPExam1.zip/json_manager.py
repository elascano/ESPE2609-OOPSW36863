import json
import os
from typing import List
from models.truck import Truck


class TruckJsonManager:
    def __init__(self, file_path: str = "data/trucks.json"):
        self._file_path = file_path
        self._ensure_file_exists()

    def _ensure_file_exists(self) -> None:
   
        directory = os.path.dirname(self._file_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory, exist_ok=True)
            
        if not os.path.exists(self._file_path):
            self.save_trucks([])

    def save_trucks(self, trucks: List[Truck]) -> None:

        try:
            with open(self._file_path, 'w', encoding='utf-8') as file:
                data = [truck.to_dict() for truck in trucks]
                json.dump(data, file, indent=4)
        except OSError as error:
            raise RuntimeError(f"Failed to write to JSON file: {error}")

    def read_trucks(self) -> List[Truck]:
   
        if not os.path.exists(self._file_path):
            return []

        try:
            with open(self._file_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
                return [Truck.from_dict(item) for item in data]
        except (json.JSONDecodeError, OSError):
            return []