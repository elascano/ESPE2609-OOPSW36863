class Truck:
    def __init__(self, truck_id: str, brand: str, payload_capacity_kg: float, year: int):
        self.id = truck_id
        self.brand = brand
        self.payload_capacity_kg = payload_capacity_kg
        self.year = year

    def to_dict(self) -> dict:
    
        return {
            "id": self.id,
            "brand": self.brand,
            "payload_capacity_kg": self.payload_capacity_kg,
            "year": self.year
        }

    @staticmethod
    def from_dict(data: dict) -> "Truck":
  
        return Truck(
            truck_id=data.get("id", ""),
            brand=data.get("brand", ""),
            payload_capacity_kg=float(data.get("payload_capacity_kg", 0.0)),
            year=int(data.get("year", 0))
        )

    def __str__(self) -> str:
        return (f"Truck [ID: {self.id} | Brand: {self.brand} | "
                f"Payload: {self.payload_capacity_kg} kg | Year: {self.year}]")