import * as fs from "fs";
import { FlashDrive } from "../model/FlashDrive";

/**
 * Data class: saves and reads the list of flash drives in/from a JSON file.
 * Uses only the "fs" module that comes with Node.js (no external libraries).
 */
export class FlashDriveJsonFile {
    private filePath: string;

    constructor(filePath: string) {
        this.filePath = filePath;
    }

    public getFilePath(): string {
        return this.filePath;
    }

    /** Writes the whole list into the JSON file */
    public save(flashDriveList: Array<FlashDrive>): void {
        const plainList: Array<object> = [];

        for (const flashDrive of flashDriveList) {
            plainList.push({
                id: flashDrive.getId(),
                brand: flashDrive.getBrand(),
                capacityGB: flashDrive.getCapacityGB(),
                usbVersion: flashDrive.getUsbVersion()
            });
        }

        const jsonText: string = JSON.stringify(plainList, null, 4);
        fs.writeFileSync(this.filePath, jsonText, "utf-8");
    }

    /** Reads the JSON file and returns the list of FlashDrive objects */
    public read(): Array<FlashDrive> {
        const flashDriveList: Array<FlashDrive> = [];

        if (!fs.existsSync(this.filePath)) {
            return flashDriveList;
        }

        const jsonText: string = fs.readFileSync(this.filePath, "utf-8");
        if (jsonText.trim() === "") {
            return flashDriveList;
        }

        const plainList: Array<any> = JSON.parse(jsonText);
        for (const item of plainList) {
            const flashDrive = new FlashDrive(item.id, item.brand, item.capacityGB, item.usbVersion);
            flashDriveList.push(flashDrive);
        }

        return flashDriveList;
    }
}
