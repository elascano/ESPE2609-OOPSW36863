import * as readline from "readline";
import { FlashDrive } from "../model/FlashDrive";
import { FlashDriveJsonFile } from "../data/FlashDriveJsonFile";




export class ConsoleMenu {
    private flashDriveList: Array<FlashDrive>;
    private jsonFile: FlashDriveJsonFile;
    private reader: readline.Interface;
    private pendingLines: Array<string> = [];
    private waitingAnswer: ((answer: string) => void) | null = null;

    constructor(jsonFile: FlashDriveJsonFile) {
        this.jsonFile = jsonFile;
        this.flashDriveList = jsonFile.read();
        this.reader = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
            terminal: false
        });
        this.reader.on("line", (line: string) => this.receiveLine(line));
    }


    

    private ask(question: string): Promise<string> {
        process.stdout.write(question);
        return new Promise((resolve) => {
            if (this.pendingLines.length > 0) {
                resolve((this.pendingLines.shift() as string).trim());
            } else {
                this.waitingAnswer = resolve;
            }
        });
    }


    
    private receiveLine(line: string): void {
        if (this.waitingAnswer !== null) {
            const answer = this.waitingAnswer;
            this.waitingAnswer = null;
            answer(line.trim());
        } else {
            this.pendingLines.push(line);
        }
    }

    

    private async askPositiveNumber(question: string): Promise<number> {
        while (true) {
            const answer: string = await this.ask(question);
            const number: number = Number(answer);
            if (answer !== "" && Number.isInteger(number) && number > 0) {
                return number;
            }
            console.log("  Invalid value. Enter a whole number greater than 0.");
        }
    }

    
    private async askText(question: string): Promise<string> {
        while (true) {
            const answer: string = await this.ask(question);
            if (answer !== "") {
                return answer;
            }
            console.log("  This field cannot be empty.");
        }
    }

    

    private idExists(id: number): boolean {
        for (const flashDrive of this.flashDriveList) {
            if (flashDrive.getId() === id) {
                return true;
            }
        }
        return false;
    }

    

    private async createFlashDrive(): Promise<void> {
        console.log("\n--- CREATE FLASH DRIVE ---");

        let id: number = await this.askPositiveNumber("Id: ");
        while (this.idExists(id)) {
            console.log("  That id already exists. Try another one.");
            id = await this.askPositiveNumber("Id: ");
        }

        const brand: string = await this.askText("Brand: ");
        const capacityGB: number = await this.askPositiveNumber("Capacity (GB): ");
        const usbVersion: string = await this.askText("USB version (e.g. 2.0, 3.0, 3.2): ");

        const flashDrive = new FlashDrive(id, brand, capacityGB, usbVersion);
        this.flashDriveList.push(flashDrive);
        this.jsonFile.save(this.flashDriveList);

        console.log("Flash drive saved in " + this.jsonFile.getFilePath());
    }


    

    private showFlashDrives(): void {
        console.log("\n--- FLASH DRIVES IN THE JSON FILE ---");

        this.flashDriveList = this.jsonFile.read();

        if (this.flashDriveList.length === 0) {
            console.log("There are no flash drives registered.");
            return;
        }

        for (const flashDrive of this.flashDriveList) {
            console.log(flashDrive.toString());
        }
        console.log("Total: " + this.flashDriveList.length);
    }


    
    
    public async start(): Promise<void> {
        let option: string = "";

        while (option !== "0") {
            console.log("\n===== FLASH DRIVE MANAGER =====");
            console.log("1. Create flash drive");
            console.log("2. Show flash drives (read JSON)");
            console.log("0. Exit");
            option = await this.ask("Choose an option: ");

            switch (option) {
                case "1":
                    await this.createFlashDrive();
                    break;
                case "2":
                    this.showFlashDrives();
                    break;
                case "0":
                    console.log("Goodbye!");
                    break;
                default:
                    console.log("Invalid option.");
            }
        }

        this.reader.close();
    }
}
