


export class FlashDrive {
    private id: number;
    private brand: string;
    private capacityGB: number;
    private usbVersion: string;

    constructor(id: number, brand: string, capacityGB: number, usbVersion: string) {
        this.id = id;
        this.brand = brand;
        this.capacityGB = capacityGB;
        this.usbVersion = usbVersion;
    }

    // getters
    public getId(): number {
        return this.id;
    }

    public getBrand(): string {
        return this.brand;
    }

    public getCapacityGB(): number {
        return this.capacityGB;
    }

    public getUsbVersion(): string {
        return this.usbVersion;
    }

    // setters
    public setId(id: number): void {
        this.id = id;
    }

    public setBrand(brand: string): void {
        this.brand = brand;
    }

    public setCapacityGB(capacityGB: number): void {
        this.capacityGB = capacityGB;
    }

    public setUsbVersion(usbVersion: string): void {
        this.usbVersion = usbVersion;
    }


    
    
    public toString(): string {
        return "FlashDrive{id=" + this.id +
            ", brand='" + this.brand + "'" +
            ", capacityGB=" + this.capacityGB +
            ", usbVersion='" + this.usbVersion + "'}";
    }
}
