import * as path from "path";
import { FlashDriveJsonFile } from "./data/FlashDriveJsonFile";
import { ConsoleMenu } from "./view/ConsoleMenu";




const filePath: string = path.join(__dirname, "..", "data", "flashDrives.json");
const jsonFile = new FlashDriveJsonFile(filePath);
const menu = new ConsoleMenu(jsonFile);

menu.start();
